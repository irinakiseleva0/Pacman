"""Packaged JSON configuration resources."""
