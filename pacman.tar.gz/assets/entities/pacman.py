from __future__ import annotations

import math

import pygame

import core.raylib_api as pyray
from core import colors

from core.progression import unlocked_abilities
from entities.ability import Ability, default_abilities
from entities.cell import Actor
from ui import gamepad
from utils.animated_sprite import Sprite
from assets.assets import Assets
from ui.ui import LIVE_CYAN, LIVE_GOLD
from utils.effects import shake_camera
from utils.visual_effects import Particle, with_alpha


class State:
    UP = "UP"
    RIGHT = "RIGHT"
    DOWN = "DOWN"
    LEFT = "LEFT"
    DEAD = "DEATH"
    NONE = "NONE"


class Pacman(Actor):
    _images_cache = None
    TURN_BUFFER_SECONDS = 0.28
    CORNER_GRACE_SECONDS = 0.08

    def __init__(self, ctx) -> None:
        super().__init__(ctx)

        self.kind = "pacman"
        self.state = State.UP
        self.next_state = self.state

        self.rage = False
        self.rage_timer = 0
        self.death_timer = 0
        self.turn_feedback_timer = 0.0
        self.turn_feedback_dir = (0, -1)
        self.turn_buffer_timer = 0.0
        self.turn_grace_timer = 0.0
        self.abilities: list[Ability] = default_abilities(unlocked_abilities(ctx))[:3]
        self.ability_speed_multiplier = 1.0
        self.ability_invulnerable = False
        self.ability_slow_ghosts = False

        # Track last movement direction for ghost AI
        self.last_dx = 0
        self.last_dy = -1  # Start facing up

        if Pacman._images_cache is None:
            Pacman._images_cache = self._load_images()

        self.pacman_sprite = Sprite(Pacman._images_cache)
        self.pacman_sprite.set_key(self.state, True)

    @staticmethod
    def _load_images():
        if Assets.entity_spritesheet() is not None:
            blank = pygame.Surface((1, 1), pygame.SRCALPHA)
            return {
                "UP": [blank, blank],
                "DOWN": [blank, blank],
                "LEFT": [blank, blank],
                "RIGHT": [blank, blank],
                "DEATH": [blank for _ in range(10)],
                "NONE": [],
            }

        base = "sprites/pacman/"
        paths = {
            "UP": [f"{base}pacman_pos_1_up.png", f"{base}pacman_pos_2_up.png"],
            "DOWN": [f"{base}pacman_pos_1_down.png", f"{base}pacman_pos_2_down.png"],
            "LEFT": [f"{base}pacman_pos_1_left.png", f"{base}pacman_pos_2_left.png"],
            "RIGHT": [f"{base}pacman_pos_1_right.png", f"{base}pacman_pos_2_right.png"],
            "DEATH": [f"{base}death/death_{i}.png" for i in range(1, 11)],
            "NONE": [],
        }
        return {key: [Assets.texture_for_scene(path, "gameplay") for path in value] for key, value in paths.items()}

    def _atlas_key(self) -> str | None:
        frame = self.pacman_sprite.frame_index
        if self.state == State.DEAD:
            return f"pacman_death_{frame}"
        if self.state == State.RIGHT:
            return f"pacman_right_{frame % 2}"
        if self.state == State.LEFT:
            return f"pacman_left_{frame % 2}"
        if self.state == State.UP:
            return f"pacman_up_{frame % 2}"
        if self.state == State.DOWN:
            return f"pacman_down_{frame % 2}"
        return None

    def _draw_sprite(self, x: float, y: float, scale: float) -> None:
        key = self._atlas_key()
        spritesheet = Assets.entity_spritesheet()
        index = Assets.entity_sprite_index(key) if key is not None else None
        if spritesheet is not None and index is not None:
            spritesheet.draw(index, x, y, scale=scale)
            return
        self.pacman_sprite.draw((x, y), scale=scale)

    def enable_rage(self, ticks: int, *, keep_combo: bool = False) -> None:
        if self.state in (State.DEAD, State.NONE):
            return

        self.rage = True
        self.rage_timer = ticks
        if not keep_combo:
            self.ctx.reset_ghost_combo()

    def kill(self) -> None:
        if self.state in (State.DEAD, State.NONE):
            return
        if self.is_invulnerable():
            return

        self.rage = False
        self.rage_timer = 0
        self.ctx.reset_ghost_combo()
        shake_camera(8, 0.3)
        self.death_timer = 0
        self.state = State.DEAD
        self.next_state = State.DEAD
        self.pacman_sprite.set_key(State.DEAD, True)

    def is_invulnerable(self) -> bool:
        return self.ability_invulnerable or any(
            ability.name == "Shield" and ability.is_active()
            for ability in self.abilities
        )

    def ghosts_are_slowed(self) -> bool:
        return self.ability_slow_ghosts or any(
            ability.name == "Slow" and ability.is_active()
            for ability in self.abilities
        )

    def refresh_ability_modifiers(self) -> None:
        self.ability_speed_multiplier = 1.0
        self.ability_invulnerable = False
        self.ability_slow_ghosts = False
        for ability in self.abilities:
            if ability.is_active():
                ability.on_update(self, 0.0)

    def activate_ability_slot(self, slot: int) -> bool:
        if self.state in (State.NONE, State.DEAD):
            return False
        if slot < 0 or slot >= len(self.abilities):
            return False
        activated = self.abilities[slot].activate(self)
        if activated:
            self.ctx.trigger_screen_flash(self.ctx.effect_palette()["power_flash"], 0.06, 0.04)
        return activated

    def update_abilities(self, dt: float) -> None:
        self.refresh_ability_modifiers()
        for ability in self.abilities:
            ability.update(self, dt)

    def draw(self) -> None:
        if self.state == State.NONE:
            return

        cfg = self.ctx.cfg
        scale = cfg.tile_size / 16
        time_s = getattr(self.ctx, "visual_time", 0.0)
        base_x = cfg.board_offset_x + self.x * cfg.tile_size
        base_y = cfg.board_offset_y + self.y * cfg.tile_size
        px = base_x + cfg.tile_size // 2
        py = base_y + cfg.tile_size // 2
        pulse = 0.5 + 0.5 * math.sin(time_s * 6.0)
        glow_radius = max(10, cfg.tile_size // 2 + int(pulse * 7))
        outer_glow = LIVE_GOLD if self.rage else (255, 220, 80, 255)
        dir_dx, dir_dy = self._direction_to_delta(self.state)
        for index in range(4, 0, -1):
            trail_x = px - dir_dx * index * 2
            trail_y = py - dir_dy * index * 2
            pyray.draw_circle(trail_x, trail_y, glow_radius + 6 - index, with_alpha(outer_glow, 14 + index * 6))
        # Breathing aura makes Pac-Man feel like a living neon object, not a flat sprite.
        pyray.draw_circle(px, py, glow_radius + 32, with_alpha(outer_glow, 18))
        pyray.draw_circle(px, py, glow_radius + 24, with_alpha(outer_glow, 34))
        pyray.draw_circle(px, py, glow_radius + 14, with_alpha(outer_glow, 62))
        pyray.draw_circle(px, py, max(8, cfg.tile_size // 3 + 3), with_alpha(colors.WHITE, 42))
        if self.turn_feedback_timer > 0:
            turn_alpha = min(1.0, self.turn_feedback_timer / 0.14)
            ring_color = colors.ORANGE if not self.rage else colors.GOLD
            ring_radius = max(8, cfg.tile_size // 2 + int((1.0 - turn_alpha) * 10))
            pyray.draw_circle_lines(px, py, ring_radius, with_alpha(ring_color, 180 * turn_alpha))
            dx, dy = self.turn_feedback_dir
            if dx != 0 or dy != 0:
                dash_w = max(3, cfg.tile_size // 5)
                dash_h = max(3, cfg.tile_size // 5)
                dash_x = int(px + dx * (cfg.tile_size * 0.55) - dash_w / 2)
                dash_y = int(py + dy * (cfg.tile_size * 0.55) - dash_h / 2)
                pyray.draw_rectangle_rec(
                    pyray.Rectangle(dash_x, dash_y, dash_w, dash_h),
                    with_alpha(colors.WHITE, 210 * turn_alpha),
                )
        self._draw_sprite(base_x, base_y, scale)
        highlight_x = px - dir_dx * 2 - dir_dy
        highlight_y = py - dir_dy * 2 + dir_dx
        pyray.draw_circle(highlight_x, highlight_y, max(4, cfg.tile_size // 4), with_alpha(colors.WHITE, 36))
        pyray.draw_circle(px + dir_dx * 4, py + dir_dy * 4, max(2, cfg.tile_size // 6), with_alpha(LIVE_CYAN, 20 if self.rage else 10))
        pyray.draw_circle(px, py, max(3, cfg.tile_size // 5), with_alpha(colors.WHITE, 18 + int(pulse * 14)))
        # Crisp lower rim helps the sprite sit on the darker stage.
        pyray.draw_rectangle_rec(
            pyray.Rectangle(base_x + 4, base_y + cfg.tile_size - 4, max(4, cfg.tile_size - 8), 2),
            with_alpha((255, 208, 92, 255), 116),
        )

    def _direction_to_delta(self, state: str) -> tuple[int, int]:
        if state == State.RIGHT:
            return 1, 0
        if state == State.LEFT:
            return -1, 0
        if state == State.UP:
            return 0, -1
        if state == State.DOWN:
            return 0, 1
        return 0, 0

    def _can_move_in_direction(self, state: str) -> bool:
        game_map = self.ctx.runtime.game_map
        if game_map is None:
            return False

        dx, dy = self._direction_to_delta(state)
        if dx == 0 and dy == 0:
            return False

        next_cell = game_map.get_cell(self.x + dx, self.y + dy)
        if next_cell is None:
            return False

        return not next_cell.is_blocking(self)

    def _apply_buffered_turn(self) -> None:
        if self.next_state in (State.NONE, State.DEAD):
            return
        if self.turn_buffer_timer <= 0 and self.turn_grace_timer <= 0:
            return

        if self._can_move_in_direction(self.next_state):
            if self.state != self.next_state:
                self.state = self.next_state
                self.pacman_sprite.set_key(self.state, False)
                self._trigger_turn_feedback()
            self.turn_buffer_timer = 0.0

    def _post_move_turn_snap(self) -> None:
        if self.next_state in (State.NONE, State.DEAD):
            return
        if self.turn_buffer_timer <= 0 and self.turn_grace_timer <= 0:
            return
        if self.state == self.next_state:
            self.turn_buffer_timer = 0.0
            self.turn_grace_timer = 0.0
            return
        if self._can_move_in_direction(self.next_state):
            self.state = self.next_state
            self.pacman_sprite.set_key(self.state, False)
            self._trigger_turn_feedback()
            self.turn_buffer_timer = 0.0
            self.turn_grace_timer = 0.0

    def _attempt_turn_when_blocked(self) -> bool:
        if self.next_state in (State.NONE, State.DEAD):
            return False
        if self.turn_buffer_timer <= 0 and self.turn_grace_timer <= 0:
            return False
        if not self._can_move_in_direction(self.next_state):
            return False
        self.state = self.next_state
        self.pacman_sprite.set_key(self.state, False)
        self._trigger_turn_feedback()
        self.turn_buffer_timer = 0.0
        self.turn_grace_timer = 0.0
        return True

    def _trigger_turn_feedback(self) -> None:
        dx, dy = self._direction_to_delta(self.state)
        self.turn_feedback_timer = 0.14
        self.turn_feedback_dir = (dx, dy)

        center_x = self.x * 16 + 8
        center_y = self.y * 16 + 8
        accent = colors.GOLD if self.rage else self.ctx.effect_palette()["dot"]
        for index in range(4):
            spread = (index - 1.5) * 0.22
            speed = 22 + index * 8
            vx = (dx + (dy * spread)) * speed
            vy = (dy - (dx * spread)) * speed
            self.ctx.particles.add_particle(
                # Compatibility facade still works, but route effects are owned by visual systems.
                Particle(
                    center_x,
                    center_y,
                    vx,
                    vy,
                    0.12 + index * 0.02,
                    accent if index < 3 else colors.WHITE,
                    1.0 + index * 0.2,
                )
            )
        self.ctx.trigger_screen_shake(0.5, 0.04)

    def queue_direction(self, state: str) -> None:
        if state not in (State.UP, State.DOWN, State.LEFT, State.RIGHT):
            return
        if self.state in (State.NONE, State.DEAD):
            return
        self.next_state = state
        self.turn_buffer_timer = self.TURN_BUFFER_SECONDS

    def process(self) -> None:
        if self.state in (State.NONE, State.DEAD):
            return

        game_map = self.ctx.runtime.game_map
        if game_map is None:
            return

        self._apply_buffered_turn()

        dx, dy = self._direction_to_delta(self.state)
        steps = max(1, int(round(self.ability_speed_multiplier)))
        result = game_map.try_move(self, dx, dy)

        if result.moved:
            self.last_dx = dx
            self.last_dy = dy
            self._post_move_turn_snap()
            self.pacman_sprite.move_forward()
            if dx != 0 or dy != 0:
                trail_color = colors.GOLD if self.rage else with_alpha((255, 222, 96, 255), 220)
                center_x = self.x * 16 + 8 - dx * 5
                center_y = self.y * 16 + 8 - dy * 5
                intensity = 1.15 if self.rage else 0.72
                self.ctx.visual.light_bursts.add_burst(center_x, center_y, 10, trail_color, intensity * 0.75, 0.09)
                self.ctx.visual.particles.add_particle(
                    Particle(center_x, center_y, -dx * 10, -dy * 10, 0.14, trail_color, 2.0 if self.rage else 1.4)
                )
            for _index in range(1, steps):
                if self.state in (State.NONE, State.DEAD) or not self._can_move_in_direction(self.state):
                    break
                dash_result = game_map.try_move(self, dx, dy)
                if not dash_result.moved:
                    break
                self.pacman_sprite.move_forward()
        elif result.blocked:
            if self._attempt_turn_when_blocked():
                ndx, ndy = self._direction_to_delta(self.state)
                retry = game_map.try_move(self, ndx, ndy)
                if retry.moved:
                    self.last_dx = ndx
                    self.last_dy = ndy
                    self.pacman_sprite.move_forward()

    def frame(self, x: int, y: int) -> None:
        super().frame(x, y)

        if self.state == State.NONE:
            return

        if self.state == State.DEAD:
            self.death_timer += 1

            if self.death_timer % self.ctx.cfg.death_animation_fps == 0:
                self.pacman_sprite.move_forward()
                frames = self.pacman_sprite.texture_dictionary[State.DEAD]
                if self.pacman_sprite.frame_index >= len(frames) - 1:
                    self.state = State.NONE

            return

        if self.turn_feedback_timer > 0:
            self.turn_feedback_timer = max(0.0, self.turn_feedback_timer - pyray.get_frame_time())
        if self.turn_buffer_timer > 0:
            self.turn_buffer_timer = max(0.0, self.turn_buffer_timer - pyray.get_frame_time())
            if self.turn_buffer_timer == 0 and self.next_state != self.state:
                self.turn_grace_timer = max(self.turn_grace_timer, self.CORNER_GRACE_SECONDS)
        if self.turn_grace_timer > 0:
            self.turn_grace_timer = max(0.0, self.turn_grace_timer - pyray.get_frame_time())
            if self.turn_grace_timer == 0 and self.next_state != self.state:
                self.next_state = self.state

        self.update_abilities(pyray.get_frame_time())

        if self.rage_timer > 0:
            self.rage_timer -= 1
            if self.rage_timer == 0:
                self.rage = False
                self.ctx.begin_power_chain_window()

        keys = {
            pygame.K_w: State.UP,
            pygame.K_UP: State.UP,
            pygame.K_a: State.LEFT,
            pygame.K_LEFT: State.LEFT,
            pygame.K_s: State.DOWN,
            pygame.K_DOWN: State.DOWN,
            pygame.K_d: State.RIGHT,
            pygame.K_RIGHT: State.RIGHT,
        }

        ability_keys = (
            (pygame.K_q, 0),
            (pygame.K_e, 1),
            (pygame.K_r, 2),
        )
        pressed_events = pyray.get_pressed_key_events()
        for key, slot in ability_keys:
            if key in pressed_events:
                self.activate_ability_slot(slot)
                return

        for key, state in keys.items():
            if key in pressed_events:
                self.queue_direction(state)
                return

        pressed = pyray.get_pressed_keys()
        held_states = {
            state
            for key, state in keys.items()
            if pressed[key]
        }
        if len(held_states) == 1:
            self.queue_direction(next(iter(held_states)))
            return

        controller_direction = gamepad.movement_direction()
        if controller_direction == "up":
            self.queue_direction(State.UP)
        elif controller_direction == "down":
            self.queue_direction(State.DOWN)
        elif controller_direction == "left":
            self.queue_direction(State.LEFT)
        elif controller_direction == "right":
            self.queue_direction(State.RIGHT)
